let week = 1;
function nextWeek() {
    week++;
    document.getElementById('status').innerText = "Semaine actuelle : " + week;
}
document.getElementById('status').innerText = "Semaine actuelle : " + week;
